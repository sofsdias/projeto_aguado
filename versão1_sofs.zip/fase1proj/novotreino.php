<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/novotreino.css">
    <title>Novo Treino</title>
</head>
<body>
    <div class="container">
        <div class="form">
            <h2> Para que possamos entregar um resultado exclusivo e personalizado para você, é necessário que algumas informações sejam fornecidas:
            </h2>
            <form>
                <label class="label"> Idade </label>
                <input type="text" required>

                <label class="label"> Objetivo </label>
                <input type="radio">
    
                <label class="label">Áreas-Alvo </label>
                <input type="radio" required>
      
                <label class="label"> Foco</label>
                <input type="radio" required>
 
                <label class="label"> Nível de Condicionamento Físico </label>
                <input type="radio" required>

                <label class="label"> Altura em cm </label>
                <input type="radio" required>

                <label class="label"> Peso em kg </label>
                <input type="radio" required>
            </form>

            <button> Montar meu treino </button>

        </div>












    </div>
</body>
</html>